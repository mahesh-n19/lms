package question2;

public class BST {
	static class Node{
		private int data;
		private Node left;
		private Node right;
		
		public Node(int value) {
			this.data = value;
			this.left = null;
			this.right = null;
		}
		
		public String toString() {
			return String.format("node data: %d", this.data);
		}
	}
	
	private Node root;
	
	public BST() {
		this.root = null;
	}
	
	public boolean isEmpty() {
		return (this.root == null);
	}
	
	public void addNode(int value) {
		Node newNode = new Node(value);
		
		if(root == null) {
			root = newNode;
			return;
		}
		
		Node trav = root;
		while(true) {
			if(value < trav.data) {
				if(trav.left == null) {
					trav.left = newNode;
					return;
				}
				trav = trav.left;
			} else {
				if(trav.right == null) {
					trav.right = newNode;
					return;
				}
				trav = trav.right;
			}
		}
	}
	
	private void inorder(Node root) {
		Node trav = root;
		if(trav == null) return;
		inorder(trav.left);
		System.out.print(trav.data + " ");
		inorder(trav.right);
	}
	
	public void inorder() {
		System.out.println("Inorder traversal of the tree: ");
		inorder(this.root);
		System.out.println();
	}
	
	public Node findSuccessor(int data) {
		Node trav = root;
		Node parent = null;
		while(trav != null) {
			if(trav.data == data)
				break;
			parent = trav;
			if(data < trav.data) 
				trav = trav.left;
			else
				trav = trav.right;
		}
		
		if(trav == null) {
			System.out.println("Given value not found in tree");
			return null;
		}
			
		else {
			if (trav.right == null) {
				System.out.println("No successor exist for this node");
				return null;
			}	
			else return trav.right;
		}
	}
	
	
}

