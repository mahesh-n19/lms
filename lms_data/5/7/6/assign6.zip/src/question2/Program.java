package question2;

import java.util.Scanner;

public class Program {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		BST bstree = new BST();
		
		bstree.addNode(5);
		bstree.addNode(2);
		bstree.addNode(1);
		bstree.addNode(3);
		bstree.addNode(7);
		bstree.addNode(6);
		bstree.addNode(9);
		
		bstree.inorder();
		
		System.out.print("Enter node value to find successor: ");
		int data = sc.nextInt();
		
		BST.Node successorNode = bstree.findSuccessor(data);
		if (successorNode != null) System.out.println(successorNode);
		
		
	}
}
