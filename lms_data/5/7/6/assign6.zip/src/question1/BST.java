package question1;

public class BST {
	static class Node{
		private int data;
		private Node left;
		private Node right;
		
		public Node(int value) {
			this.data = value;
			this.left = null;
			this.right = null;
		}
		
		public String toString() {
			return String.format("node data: %d", this.data);
		}
	}
	
	private Node root;
	
	public BST() {
		this.root = null;
	}
	
	public boolean isEmpty() {
		return (this.root == null);
	}
	
	public void addNode(int value) {
		Node newNode = new Node(value);
		
		if(root == null) {
			root = newNode;
			return;
		}
		
		Node trav = root;
		while(true) {
			if(value < trav.data) {
				if(trav.left == null) {
					trav.left = newNode;
					return;
				}
				trav = trav.left;
			} else {
				if(trav.right == null) {
					trav.right = newNode;
					return;
				}
				trav = trav.right;
			}
		}
	}
	
	private void inorder(Node root) {
		Node trav = root;
		if(trav == null) return;
		inorder(trav.left);
		System.out.print(trav.data + " ");
		inorder(trav.right);
	}
	
	public void inorder() {
		System.out.println("Inorder traversal of the tree: ");
		inorder(this.root);
		System.out.println();
	}
	
	public Node searchNode(int key) {
		Node trav = this.root;
		
		while(trav != null) {
			if (trav.data == key) return trav;
			
			if(key < trav.data) trav = trav.left;
			
			else trav = trav.right;
		}
		return null;
	}
	
	private Node recursiveSearch(Node node, int key) {
		Node trav = node;
		
		if(trav == null) return null;
		
		if (trav.data == key) return trav;
		
		if (key < trav.data) return recursiveSearch(trav.left, key);
		
		return recursiveSearch(trav.right, key);
	}
	
	public Node recursiveSearch(int key) {
		return recursiveSearch(this.root, key);
	}
	
	
}
